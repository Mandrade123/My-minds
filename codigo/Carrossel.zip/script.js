document.addEventListener("DOMContentLoaded", function () {
  const swiper = new Swiper(".swiper", {
    cssMode: true,
    loop: true,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    pagination: {
      el: ".swiper-pagination",
    },
    keyboard: true,
  });

  const projectImgs = document.querySelectorAll(".project-img");

  projectImgs.forEach((img) => {
    img.addEventListener("mouseover", function () {
      this.classList.add("active");
    });

    img.addEventListener("mouseout", function () {
      this.classList.remove("active");
    });
  });
});
