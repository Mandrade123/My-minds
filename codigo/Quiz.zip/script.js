
var quiz = {
  questions: [
    {
      question: "Você se sente constantemente preocupado ou tenso?",
      answers: ["Não", "Sim"]
    },
    {
      question: "Você tem dificuldade para dormir ou fica com sono em excesso?",
      answers: ["Não", "Sim"]
    },
    {
      question: "Você não se sente capaz de lidar com as suas preocupações?",
      answers: ["Não", "Sim"]
    },
    {
      question: "Você possui dificuldade para relaxar?",
      answers: ["Não", "Sim"]
    },
    {
      question: "Você se sente tão agitado que não consegue ficar sentado?",
      answers: ["Não", "Sim"]
    },
  ],
  
  results: [
     {
    scoreRange: [0, 1],
    title: "Baixa Ansiedade",
    description: "Seus níveis de ansiedade são baixos. Continue cuidando de si mesmo e pratique técnicas de relaxamento para se manter saudável mentalmente."
  },
  {
    scoreRange: [2, 3],
    title: "Ansiedade Moderada",
    description: "Você apresenta um nível moderado de ansiedade. Considere buscar apoio de um profissional de saúde mental para ajudá-lo a gerenciar seus sintomas."
  },
  {
    scoreRange: [4, 5],
    title: "Alta Ansiedade",
    description: "Seus níveis de ansiedade são altos. É importante procurar ajuda profissional para avaliar e tratar sua ansiedade. Você não precisa enfrentar isso sozinho(a)."
  },
  ]
};

function displayQuiz() {
  var quizContainer = document.getElementById("quiz-container");
  var questionsContainer = document.getElementById("questions");

  var titleElement = document.createElement("h2");
  titleElement.textContent = quiz.title;

  var descriptionElement = document.createElement("p");
  descriptionElement.textContent = quiz.description;

  quizContainer.appendChild(titleElement);
  quizContainer.appendChild(descriptionElement);
  quizContainer.appendChild(questionsContainer);

  var questions = quiz.questions;

  questions.forEach(function(question, index) {
    var questionContainer = document.createElement("div");
    questionContainer.classList.add("question");

    var questionText = document.createElement("p");
    questionText.textContent = question.question;

    questionContainer.appendChild(questionText);

    question.answers.forEach(function(answer, answerIndex) {
      var answerContainer = document.createElement("div");
      answerContainer.classList.add("answer");

      var answerInput = document.createElement("input");
      answerInput.setAttribute("type", "radio");
      answerInput.setAttribute("name", "question-" + index);
      answerInput.setAttribute("value", answerIndex);

      var answerLabel = document.createElement("label");
      answerLabel.textContent = answer;

      answerContainer.appendChild(answerInput);
      answerContainer.appendChild(answerLabel);

      questionContainer.appendChild(answerContainer);
    });

    questionsContainer.appendChild(questionContainer);
  });

  var submitButton = document.getElementById("submit-button");
  submitButton.addEventListener("click", submitQuiz);

  var startButton = document.getElementById("start-button");
  startButton.addEventListener("click", startQuiz);
}

function startQuiz() {
  var startButton = document.getElementById("start-button");
  var questionsContainer = document.getElementById("questions");
  var submitButton = document.getElementById("submit-button");

  startButton.style.display = "none";
  questionsContainer.style.display = "block";
  submitButton.style.display = "block";
}

function calculateScore() {
  var answers = document.querySelectorAll('input[type="radio"]:checked');
  var score = 0;

  answers.forEach(function(answer) {
    var questionIndex = answer.name.split("-")[1];
    var answerIndex = parseInt(answer.value);
    var question = quiz.questions[questionIndex];
    score += answerIndex;
  });

  return score;
}

function showResult() {
  var resultContainer = document.getElementById("result-container");
  resultContainer.innerHTML = "";

  var score = calculateScore();
  var results = quiz.results;

  var resultTitle = document.createElement("h3");
  resultTitle.textContent = "Resultado";

  resultContainer.appendChild(resultTitle);

  for (var i = 0; i < results.length; i++) {
    var result = results[i];
    if (score >= result.scoreRange[0] && score <= result.scoreRange[1]) {
      var resultTitle = document.createElement("h3");
      resultTitle.textContent = result.title;

      var resultDescription = document.createElement("p");
      resultDescription.textContent = result.description;

      resultContainer.appendChild(resultTitle);
      resultContainer.appendChild(resultDescription);

      break;
    }
  }
}

function submitQuiz() {
  var questionsContainer = document.getElementById("questions");
  var submitButton = document.getElementById("submit-button");

  questionsContainer.style.display = "none";
  submitButton.style.display = "none";

  showResult();
}

displayQuiz();
